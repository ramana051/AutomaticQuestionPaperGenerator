import React from 'react'
import logo from '../../assets/1586421714apcklogo-PhotoRoom 1.png'
import logo2 from '../../assets/APT_LOGO_2.jpg';

const Head = () => {
    return (
        <>
                    <nav className=" col-lg-12 col-sm-12 bg-white d-flex font header">

                        <div className="text-center col-2 div1">

                            <img src={logo} alt="Left Logo" width="40%" className="rounded-pill mx-sm-0" />
                        </div>

                        <div className='text-center text-black col-8 div2'>
                            <h1>Andhra Polytechnic College,Kakinada</h1>
                            <p><marquee>AFFILIATED BY STATE BOARD OF TECHNICAL EDUCATION,ANDHRA PRADESH</marquee><br />
                                AICTE APPROVED INSTITUTE</p>
                        </div>

                        <div className='text-center col-2 div3'>
                            <img src={logo2} alt="userlogo" width="40%" className='rounded-pill mx-md-0 ' />
                        </div>
                    </nav>
               
            
        </>
    )
}

export default Head