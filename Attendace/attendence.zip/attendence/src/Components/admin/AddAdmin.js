import React, { useState } from 'react'
import delete_img from '../../assets/delete.png'
import axios from 'axios'
import Head from './Head'
import user from '../../assets/Subtract.png'

const AddAdmin = () => {
    const admin=sessionStorage.getItem("user");
    const [isPanelVisible, setIsPanelVisible] = useState(false);
    const [showAdminForm, setShowAdminForm] = useState(false);
    const [data, setData] = useState({ id: "", email: "" });
    const [admin_details, setAdmin_details] = useState([]);
    const [del,setDel]=useState({email:""})
    const [loading, setLoading] = useState(false);
    const wait = (milliseconds) => new Promise(resolve => setTimeout(resolve, milliseconds));

    const onchangehandler = (e) => {
        e.preventDefault();
        setData({ ...data, [e.target.name]: e.target.value });
    }

    const togglePanel = () => {
        setIsPanelVisible(!isPanelVisible);
        const handleAddAdminClick = async () => {
            setShowAdminForm(true);
            try {
                const result = await axios.get('http://localhost:3001/admin');
                setAdmin_details(result.data);
            } catch (error) {
                console.error('Error getting admin:', error);
                console.log(error);
                alert('error getting admin');
            }
        };
        handleAddAdminClick();
    };

    const submitHandler = async (e) => {
        e.preventDefault();
        console.log(data);
        setLoading(true);
        try {
            const response = await axios.post('http://localhost:3001/addAdmin', data);
            console.log(response.data);
            if (response.data == "Add Admin Successfully") {
                alert('Add Admin Successfully');
            } else {
                alert('User already exists');
            }
        } catch (error) {
            console.error("Error inserting admin:", error);
        }finally {
            setLoading(false);
        }
    };        


    const deleteHandler= async(e)=>{
        console.log(e);
        del.email=e;
        console.log(del.email);
        setLoading(true);
        try {
            await wait(2000);

            const response = await axios.put('http://localhost:3001/deleteAdmin',del);
            console.log(response.data);
            if (response.data =="Deleted successfully") {
                alert(response.data);
            }
        } catch (error) {
            console.error("Error Deleteing admin:", error);
        }finally {
            setLoading(false);
        }
    }



    return (
        <body>
            <div><Head />
            {loading && 
                <div className="loading-overlay loading">
                <div className="spinner-border text-warning"></div>
                <div className=' text-white '>Loading...</div>
            </div>}
            <nav class="navbar navbar-expand-sm  navbar-light container rounded mt-3">
                    <div class="container-fluid">
                        <ul class="navbar-nav font ">
                            <li class="nav-item bg-white redirect2 mt-3 rounded m-2">
                                <a class="nav-link active space-between" href="newfile">Question Paper Generator</a>
                            </li>
                            <li class="nav-item bg-white mt-3 redirect2 rounded m-2">
                                <a class="nav-link" href="questionsinsertion">Insert Question</a>
                            </li>
                            <li class="nav-item   redirect h2 rounded m-2">
                               <a class="nav-link text-white" href="addadmin">Add Admin</a>
                            </li>
                        </ul>
                        {/* <h2 className='bg-white'>{admin}</h2>
                        <img src={user} alt="user" width={'5%'} /> */}
                        <div className='d-flex justify-content-end font'>
                        <h1 className='m-2 text-white'><span className='h5'>Welcome,</span>{admin}</h1>
                        <img src={user} alt="user" width={'30%'} height={'30%'}  /> 
                        </div>
                    </div>
                </nav>

                <div className='d-flex mt-4'>
                    <div className='col-lg-1 '></div>


                    <div className=' addadmin rounded-3 col-lg-10 col-sm-12  '>
                        
                            <h2>Add New Admin</h2>
                            <form onSubmit={submitHandler}>
                                <span className=' text-start'>Email</span>
                                <input type='email' className='inputfield m-3' name='email' onChange={onchangehandler} required />
                                <span className=' text-start '>Id</span>
                                <input type='text' className='inputfield m-3' name='id' onChange={onchangehandler} required />
                                <input type="submit" value='Submit' className='addadmin_btn' />
                            </form>
                       

                        <div className='d-flex  justify-content-center'>
                            <div className='col-lg-1'></div>

                            <div className=' col-lg-10 col-sm-12'>
                                <div className='slide rounded mt-2 ' id="flip" onClick={togglePanel}>
                                    Admins
                                </div>

                                {isPanelVisible && (
                                    <div className='d-flex'>
                                        <div className='panel2 col-lg-12 col-sm-12' id="panel">
                                            <div className='faculty_feed_table container'>
                                                <table className='vertical-lines'>
                                                    <thead>
                                                        <tr className='heading_border'>
                                                            <th >S.No</th>
                                                            <th>name</th>
                                                            <th>email</th>
                                                            <th>Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {(admin_details.length > 0) ? (
                                                            admin_details.map((row, index) => (
                                                                <tr key={index}>
                                                                    <td>{index + 1}</td>
                                                                    <td>{row.name}</td>
                                                                    <td>{row.email}</td>
                                                                    <td>
                                                                        <a><img src={delete_img} alt='delete'  onClick={() => deleteHandler(row.email)} /></a>
                                                                    </td>
                                                                </tr>
                                                            ))
                                                        ) : (
                                                            <tr><td colSpan="15">No admin available</td></tr>
                                                        )}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                    </div>
                                )}
                            </div>
                            <div className='col-lg-1'></div>
                        </div>
                    </div>

                    <div className='col-lg-1 '></div>

                </div>

            </div>
        </body>
    )
}

export default AddAdmin

// import React from 'react';
// import logo from '../../assets/15';
// import logo2 from '../../assets/APT_LOGO_2.jpg';
// import delete_img from '../../assets/delete.png'
// import { useState } from 'react';
// import axios from 'axios';

// const AddAdmin = () => {
// const [showAdminForm, setShowAdminForm] = useState(false);
// const [data, setData] = useState({ name: "", email: "", password: "" });
// const [admin_details,setAdmin_details]=useState([]);

//     const changeHandler = (e) => {
//         setData({ ...data, [e.target.name]: e.target.value });
//     }
//     const submitHandler = async(e) => {
//         try {
//             e.preventDefault();
//             if (data.password.length < 8) {
//                 alert('password is too short')
//             } else {
//                 console.log(data);
//                 const response=await axios.post('http://localhost:3001/addAdmin',data);
//                 alert('admin added successfully');
//             }
//         } catch (error) {
//             console.error('Error adding admin:', error);
//             console.log(error);
//             alert('error adding admin');
//         }
//     }
// const handleAddAdminClick = async() => {
//     setShowAdminForm(true);
//     document.getElementById('collapsibleNavbar').classList.remove('show');
//     try{
//         const result=await axios.get('http://localhost:3001/admin');
//         setAdmin_details(result.data);
//     }catch(error){
//         console.error('Error getting admin:', error);
//         console.log(error);
//         alert('error getting admin');
//     }
// };
//     const deleteHandler=async()=>{

//     }
//     return (
//         <body>
//             <div className='col-lg-12 col-sm-12 bg-primary'>
//                 <nav className="navbar navbar-expand-sm navbar-dark rounded d-flex">
//                     <div className="container">
//                         <img src={logo} alt="Left Logo" width="7%" className="rounded-pill mx-sm-0 " />
//                         <div className='text-center text-white'>
//                             <h1>Andhra Polytechnic College, Kakinada</h1>
//                             <p>
//                                 <marquee>AFFILIATED BY STATE BOARD OF TECHNICAL EDUCATION, ANDHRA PRADESH</marquee>
//                                 <br />
//                                 AICTE APPROVED INSTITUTE
//                             </p>
//                         </div>
//                         <img src={logo2} alt="userlogo" width="7%" className='rounded-pill mx-md-0 ' />
//                     </div>
//                 </nav>
//                 <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
//                     <div class="container-fluid">
//                         <a class="navbar-brand" href="#">ADMIN</a>
//                         <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
//                             <span class="navbar-toggler-icon"></span>
//                         </button>
//                         <div class="collapse navbar-collapse " id="collapsibleNavbar">
//                             <ul class="navbar-nav">
//                                 <li class="nav-item">
//                                     <a class="nav-link" href="newfile">GenerateQuestionPaper</a>
//                                 </li>
//                                 <li class="nav-item">
//                                     <a class="nav-link" href="showParentFeedback">InsertingQuestions</a>
//                                 </li>
//                                 <li class="nav-item">
//                                     <a class="nav-link" href="showStudentFeedback">studentFeedback</a>
//                                 </li>
//                                 <li class="nav-item dropdown">
//                                     <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Data</a>
//                                     <ul class="dropdown-menu">
//                                         <li><a class="dropdown-item" href="showStudentDetails">Student</a></li>
//                                         <li><a class="dropdown-item" href="showFacultyDetails">Faculty</a></li>
//                                         {/* <li><a class="dropdown-item" href="#">A third link</a></li> */}
//                                     </ul>
//                                 </li>
//                             </ul>
//                             <button className='login_btn '  onClick={handleAddAdminClick}>Add Admin</button>
//                         </div>
//                     </div>
//                 </nav>
//             </div>
//             {showAdminForm && (
//                 <div>
//                 <div className=" col-lg-12 row mt-5">
//                     <div className='text-center text-white'>
//                         <h3>ADD ADMIN</h3>
//                     </div>
//                     <div className='col-lg-4'></div>
//                     <div className='col-lg-4 login_block p-3 text-center '>
//                         <form onSubmit={submitHandler}>
//                             <label for='name'>Admin Name</label><br />
//                             <input type='text' name='name' id='name' className='myinputfield feedback_input' onChange={changeHandler} required /><br />
//                             <label for='email'>Admin email</label><br />
//                             <input type='email' name='email' id='email' className='myinputfield feedback_input' onChange={changeHandler} required /><br />
//                             <label for='password'>Password</label><br />
//                             <input type='password' name='password' id='password' className='myinputfield feedback_input' onChange={changeHandler} required /><br />
//                             <input type='submit' value='Add' className='login_btn sub_feed mt-3 ' />
//                         </form>
//                     </div>
//                     <div className='col-lg-4'></div>
//                 </div>
//                 <div className='text-center text-white mt-3'>
//                         <h4> ADMIN DETAILS</h4>
//                 </div>
//     <div className='row   col-lg-12 mt-3'>
//     <div className='col-lg-1'></div>
//     <div className='col-lg-10 col-sm-12 faculty_feed_table'>
//     <table className='vertical-lines'>
//         <thead>
//             <tr className='heading_border'>
//                 <th >S.No</th>
//                 <th>name</th>
//                 <th>email</th>
//                 <th>Actions</th>
//             </tr>
//         </thead>
//         <tbody>
//             {(admin_details.length > 0) ? (
//                 admin_details.map((row, index) => (
//                     <tr key={index}>
//                         <td>{index + 1}</td>
//                         <td>{row.name}</td>
//                         <td>{row.email}</td>
//                         <td>
//                             <a ><img src={delete_img} alt='delete' onClick={deleteHandler}/></a>
//                         </td>
//                     </tr>
//                 ))
//             ) : (
//                 <tr><td colSpan="15">No admin available</td></tr>
//             )}
//         </tbody>
//     </table>
// </div>
// </div>
// <div className='col-lg-1'></div>
//     </div>
// )}
//         </body>
//     );
// };

// export default AddAdmin