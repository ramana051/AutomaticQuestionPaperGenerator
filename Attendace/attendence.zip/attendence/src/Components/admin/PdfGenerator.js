// import React, { useState ,useEffect} from 'react';
// import { PDFViewer, Document, Page, Text, StyleSheet ,View ,table} from '@react-pdf/renderer';
// import axios from 'axios';
import React from 'react';
import { PDFViewer, Document, Page, Text, StyleSheet, View, Font } from '@react-pdf/renderer';
import CustomFont from '../../assets/fonts/CellofyBlack-vmBrA.otf';


// const styles = StyleSheet.create({
//   page: {
//     flexDirection: 'row',
//     backgroundColor: '#E4E4E4',
//     padding: 10,
//   },
//   section: {
//     margin: 10,
//     padding: 10,
//     flexGrow: 1,
//   },
//   title: {
//     fontSize: 24,
//     textAlign: 'center',
//     marginBottom: 10,
//   },
//   title2:{
//     fontSize:14,
//     textAlign:'center',
//   },
//   corner:{
//     // textAlign:'right',
//     paddingLeft:450,

//   },
//   text: {
//     fontSize: 12,
//     textAlign: 'justify',
//   },
// });

// const styles = StyleSheet.create({
//   page: {
//     // flexDirection: 'row',
//     backgroundColor: '#E4E4E4',
//     padding: 10,
//     alignItems: 'center'
//   },
//   section: {
//     margin: 10,
//     padding: 10,
//     flexGrow: 1,
//     flexDirection: 'row',
//   },
//   column: {
//     flexDirection: 'column',
//     flexGrow: 1,
//     margin: 5,
//     padding: 5,
//     // border: '1px solid #000',
//   },
//   title: {
//     fontSize: 24,
//     paddingLeft:90,
//     marginBottom: 10,
//   },
//   title2:{
//     fontSize:15,
//   }
// });


 // Empty 
// const MyDocument = () => (
  
//   <Document>
//   <Page size="A4" style={styles.page}>
//     <View style={styles.section}>
//       <Text style={styles.title}>Unit Text </Text>
//       <Text style={styles.corner}>c-20,cm-303</Text>
//       <Text style={styles.title2}>
//        state board of technical education  and training ,A.P
//       </Text>
//     </View>
//   </Page>
// </Document>

// {/* <Document>
// <Page size="A4" style={styles.page}>
//   <View style={styles.section}>

//     <View style={styles.column}>
//       {/* <Text style={styles.title}></Text> */}
//     </View>

//     <View style={styles.column}></View>
//     <View style={styles.column}></View>
//     <View style={styles.column}></View>
//     <View style={styles.column}>
//       <Text style={styles.title2}>C-20-CM-<Text style={styles.title}>404</Text></Text>{'\n'}
//       <Text style={styles.title}>7401</Text>
//     </View><br></br>
//     {/* <View style={styles.column}>
//     <Text style={styles.title}>7401</Text>
//     </View> */}

//   </View>
//  */}
  {/* <View style={styles.section}>

    <View style={styles.column}>
      <Text style={styles.title}>unit text</Text>
      <Text style={styles.title3}>state board of technical education ,A.P</Text>
    </View>

    <View style={styles.column}>
      <Text style={styles.title2}>C-20,CM-303</Text>
    </View>

  </View> */}

// </Page>
// </Document>
  
// );

// function PdfGenerator() {
//   const [showPreview, setShowPreview] = useState(false);

//   const handlePreviewClick = () => {
//     setShowPreview(true);
//   };

  // const handleDownloadClick = () => {
  //   // Implementing logic to download the PDF
  //   // Generating a Blob URL and creating a link to initiate download

  //   const blob = new Blob([<MyDocument />], { type: 'application/pdf' });
  //   const url = URL.createObjectURL(blob);
  //   const a = document.createElement('a');
  //   a.href = url;
  //   a.download = 'example.pdf';
  //   document.body.appendChild(a);
  //   a.click();
  //   document.body.removeChild(a);
  //   URL.revokeObjectURL(url);
  // };
  // const [rows,setRows]=useState([]);
  // useEffect(async() => {
  //   try{
  //     const result=await axios.get('http://localhost:3001/getpdf');
  //     setRows(result.data);
  //   }catch(error){
  //     console.error('Error fetching data:', error);
  //     console.log(error);
  //   }
  // },[]);
//   return (

//     <div>
//         <div>
//           <PDFViewer className='text-center' width={"100%"} height="732">
//             <MyDocument />
//           </PDFViewer>
//           {/* <button onClick={handleDownloadClick}>Download PDF</button> */}
//         </div>
        
//     </div>
//   );
// }
// export default PdfGenerator;


{/* 
Display rows in a table
<table>
  <thead>
    <tr>
      <th>Column 1</th>
      <th>Column 2</th>
      Add more headers based on your data
    </tr>
  </thead>
  <tbody>
    {rows.map((row, index) => (
      <tr key={index}>
        <td>{row.column1}</td>
        <td>{row.column2}</td>
        Map through other columns in your rows
      </tr>
    ))}
  </tbody>
</table> */}
{/* Add more Text or View components for your content */}

// import React, { useState, useEffect } from 'react';
// import { PDFViewer, Document, Page, Text, StyleSheet, View } from '@react-pdf/renderer';
// import axios from 'axios';

// const styles = StyleSheet.create({
//   page: {
//     flexDirection: 'row',
//     backgroundColor: '#E4E4E4',
//     padding: 10,
//   },
//   section: {
//     margin: 10,
//     padding: 10,
//     flexGrow: 1,
//   },
//   title: {
//     fontSize: 24,
//     textAlign: 'center',
//     marginBottom: 10,
//   },
//   title2: {
//     fontSize: 14,
//     textAlign: 'center',
//   },
//   text: {
//     fontSize: 12,
//     textAlign: 'justify',
//   },
// });

// const MyDocument = ({ rows }) => (
//   <Document>
//     <Page size="A4" style={styles.page}>
//       <View style={styles.section}>
//         <Text style={styles.title}>Unit Text</Text>
//         <Text style={styles.title2}>
//           state board of technical education and training, A.P
//         </Text>
//         <table>
//           <thead>
//             <tr>
//               <th>subject</th>
//               <th>chapter_id</th>
//               <th>question_type</th>
//               {/* Add more headers based on your data */}
//             </tr>
//           </thead>
//           <tbody>
//             {rows.map((row, index) => (
//               <tr key={index}>
//                 <td>{row.subject}</td>
//                 <td>{row.chapter_id}</td>
//                 <td>{</td>
//                 {/* Map through other columns in your rows */}
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </View>
//     </Page>
//   </Document>
// );

// function PdfGenerator() {
//   const [showPreview, setShowPreview] = useState(false);
//   const [rows, setRows] = useState([]);

//   const handlePreviewClick = () => {
//     setShowPreview(true);
//   };

//   const handleDownloadClick = () => {
//     const blob = new Blob([<MyDocument rows={rows} />], { type: 'application/pdf' });
//     const url = URL.createObjectURL(blob);
//     const a = document.createElement('a');
//     a.href = url;
//     a.download = 'example.pdf';
//     document.body.appendChild(a);
//     a.click();
//     document.body.removeChild(a);
//     URL.revokeObjectURL(url);
//   };

//   useEffect(() => {
//     async function fetchData() {
//       try {
//         const result = await axios.get('http://localhost:3001/getpdf');
//         setRows(result.data);
//       } catch (error) {
//         console.error('Error fetching data:', error);
//       }
//     }
//     fetchData();
//   }, []);

//   return (
//     <div>
//       <div>
//         <PDFViewer className='text-center' width={"100%"} height="800">
//           <MyDocument rows={rows} />
//         </PDFViewer>
//         <button onClick={handleDownloadClick}>Download PDF</button>
//       </div>
//     </div>
//   );
// }

// export default PdfGenerator;












// Register custom font
Font.register({ family: 'CustomFont', src: CustomFont });

const styles = StyleSheet.create({
  page: {
    backgroundColor: '#E4E4E4',
    padding: 10,
  },
  column: {
    flexDirection: 'column',
    flexGrow: 1,
    margin: 5,
    padding: 5,
  },
  title: {
    fontSize: 24,
    fontFamily: 'CustomFont', // Use the registered font family
    fontWeight: 'bold',
    marginBottom: 10,
  },
  title2: {
    fontSize: 15,
    fontFamily: 'CustomFont', // Use the registered font family
    // fontWeight: 'bold',
    marginBottom: 20,

  },
  title3: {
    fontSize: 13,
    fontFamily: 'CustomFont',
    marginBottom: 20,

  },
  title4: {
    fontSize: 13,
    fontFamily: 'CustomFont',
    marginBottom: 10,

  },
  end: {
    textAlign: 'right',
  },
  center: {
    textAlign: 'center',
    marginBottom: 10,

  },
  start: {
    textAlign: 'left',
  },
  pl:{
    marginLeft:20,
  },
  mg:{
    margin:40
  }
});

const MyDocument = () => {
  const semester=sessionStorage.getItem('semester');
  const sub_code=sessionStorage.getItem('subjectCode');
  const sub_name=sessionStorage.getItem('subject');
  const q1 = sessionStorage.getItem('q1');
  const q2 = sessionStorage.getItem('q2');
  const q3 = sessionStorage.getItem('q3');
  const q4 = sessionStorage.getItem('q4');
  const q5 = sessionStorage.getItem('q5');
  const q6 = sessionStorage.getItem('q6');
  const q7 = sessionStorage.getItem('q7');
  const q8 = sessionStorage.getItem('q8');
  const q9 = sessionStorage.getItem('q9');
  const q10 = sessionStorage.getItem('q10');
  const q11_a = sessionStorage.getItem('q11_a');
  const q11_b = sessionStorage.getItem('q11_b');
  const q12_a = sessionStorage.getItem('q12_a');
  const q12_b = sessionStorage.getItem('q12_b');
  const q13_a = sessionStorage.getItem('q13_a');
  const q13_b = sessionStorage.getItem('q13_b');
  const q14_a = sessionStorage.getItem('q14_a');
  const q14_b = sessionStorage.getItem('q14_b');
  const q15_a = sessionStorage.getItem('q15_a');
  const q15_b = sessionStorage.getItem('q15_b');
  const q16 = sessionStorage.getItem('q16');

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={[styles.column,styles.mg]}>
          <Text style={[styles.title2, styles.end]}>C-20-CM-<Text style={styles.title}>{sub_code}</Text></Text>
          <Text style={[styles.title, styles.center]}>7{sub_code}</Text>
          <Text style={[styles.title, styles.center]}>BOARD DIPLOMA EXAMINATION, (C-20)</Text>
          <Text style={styles.center}>MAY-2023</Text>
          <Text style={styles.center}>{semester} SEMESTER EXAMINATION</Text>
          <Text style={styles.center}>{sub_name}</Text>
          <Text style={styles.end}>
            <Text style={[ styles.title2]}>Time : 3 Hours |</Text>
            <Text style={styles.pl}>                                                    </Text>
            <Text style={[styles.title2]}>| Total Marks : 80</Text>
          </Text>
          <Text
           style={[styles.title, styles.center]}>____________________________________</Text>
          <Text style={styles.center}>PART-A</Text>
          <View style={styles.container}>
            <Text style={[styles.title2]}>Instructions :  (1)  Answer all Questions</Text>
            <Text style={[styles.title3]}>(2)Each question  carries three marks</Text>

          </View>
          <View style={styles.container}>
            <Text style={styles.title2}>1. </Text>
            <Text style={[styles.title3]}>{q1}</Text>
          </View>

          <View style={styles.container}>
            <Text style={styles.title2}>2. </Text>
            <Text style={[styles.title3]}>{q2}</Text>
          </View>

          <View style={styles.container}>
            <Text style={styles.title2}>3. </Text>
            <Text style={[styles.title3]}>{q3}</Text>
          </View>

          <View style={styles.container}>
            <Text style={styles.title2}>4. </Text>
            <Text style={[styles.title3]}>{q4}</Text>
          </View>

          <View style={styles.container}>
            <Text style={styles.title2}>5. </Text>
            <Text style={[styles.title3]}>{q5}</Text>
          </View>
          <View style={styles.container}>
            <Text style={styles.title2}>6. </Text>
            <Text style={[styles.title3]}>{q6}</Text>
          </View>
          <View style={styles.container}>
            <Text style={styles.title2}>7. </Text>
            <Text style={[styles.title3]}>{q7}</Text>
          </View>
          <View style={styles.container}>
            <Text style={styles.title2}>8. </Text>
            <Text style={[styles.title3]}>{q8}</Text>
          </View>
          <View style={styles.container}>
            <Text style={styles.title2}>9. </Text>
            <Text style={[styles.title3]}>{q9}</Text>
          </View>
          <View style={styles.container}>
            <Text style={styles.title2}>10. </Text>
            <Text style={[styles.title3]}>{q10}</Text>
          </View>
          
          <Text style={styles.center}>PART-B</Text>
          <View style={styles.container}>
            <Text style={[styles.title2]}>Instructions: (1)  Answer all Questions</Text>
          </View>
          <View style={[styles.container]}>
          <Text style={[styles.title3]}>(2) Each question carries Eight marks</Text>
          <Text style={styles.title2}>(3)   Answer should be comprehensive and the criterion for valuation is the content but not the lenght of answer</Text>
          </View>
          <View style={styles.container}>                                  </View>
          <View style={styles.container}>
            <Text style={styles.title2}>11.  (a)  </Text>
            <Text style={[styles.title3]}>{q11_a}</Text>
          </View>
          <Text style={[styles.center,styles.title3]}>(or)</Text>
          <View style={styles.container}>
            <Text style={[styles.title3,styles.pl]}>  (b)  </Text>
            <Text style={[styles.title3]}>{q11_b}</Text>
          </View>

          <View style={styles.container}>
            <Text style={styles.title2}>12.  (a)  </Text>
            <Text style={[styles.title3]}>{q12_a}</Text>
          </View>
          <Text style={[styles.center,styles.title3]}>(or)</Text>
          <View style={styles.container}>
            <Text style={[styles.title3,styles.pl]}>  (b)  </Text>
            <Text style={[styles.title3]}>{q12_b}</Text>
          </View>

          <View style={styles.container}>
            <Text style={styles.title2}>13.  (a)  </Text>
            <Text style={[styles.title3]}>{q13_a}</Text>
          </View>
          <Text style={[styles.center,styles.title3]}>(or)</Text>
          <View style={styles.container}>
            <Text style={[styles.title3,styles.pl]}>  (b)  </Text>
            <Text style={[styles.title3]}>{q13_b}</Text>
          </View>

          <View style={styles.container}>
            <Text style={styles.title2}>14.  (a)  </Text>
            <Text style={[styles.title3]}>{q14_a}</Text>
          </View>
          <Text style={[styles.center,styles.title3]}>(or)</Text>
          <View style={styles.container}>
            <Text style={[styles.title3,styles.pl]}>  (b)  </Text>
            <Text style={[styles.title3]}>{q14_b}</Text>
          </View>

          <View style={styles.container}>
            <Text style={styles.title2}>15.  (a)  </Text>
            <Text style={[styles.title3]}>{q15_a}</Text>
          </View>
          <Text style={[styles.center,styles.title3]}>(or)</Text>
          <View style={styles.container}>
            <Text style={[styles.title3,styles.pl]}>  (b)  </Text>
            <Text style={[styles.title3]}>{q15_b}</Text>
          </View>


          <Text style={styles.center}>PART-C</Text>
          <View style={styles.container}>
            <Text style={[styles.title2]}>Instructions: (1)  Answer the following Question</Text>
          </View>
          <View style={[styles.container]}>
          <Text style={[styles.title4]}>(2)Question carries TEN marks</Text>
          <Text style={styles.title3}>(3)   Answer should be comprehensive and the criterion for valuation is the content but not the lenght of answer</Text>
          </View>
         <View style={styles.container}>
            <Text style={styles.title2}>16. </Text>
            <Text style={[styles.title3]}>{q16}</Text>
          </View>

        </View>
      </Page>
    </Document>
  );
};

const PdfGenerator = () => (
  <div>
    <PDFViewer className='text-center' width={"100%"} height="732">
      <MyDocument />
    </PDFViewer>
  </div>
);

export default PdfGenerator;